
extern zend_class_entry *phalcon_mvc_collection_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Mvc_Collection_Exception);

